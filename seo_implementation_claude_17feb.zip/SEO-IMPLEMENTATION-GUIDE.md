# Waifu Gallery - Complete SEO Implementation Guide

## 📊 Table of Contents
1. [Technical SEO Fundamentals](#1-technical-seo-fundamentals)
2. [Metadata Optimization](#2-metadata-optimization)
3. [Structured Data (Schema.org)](#3-structured-data)
4. [Image SEO](#4-image-seo)
5. [Performance Optimization](#5-performance-optimization)
6. [Content Strategy](#6-content-strategy)
7. [Social Media Integration](#7-social-media-integration)
8. [Sitemap & Robots.txt](#8-sitemap--robotstxt)
9. [Implementation Checklist](#9-implementation-checklist)

---

## 1. Technical SEO Fundamentals

### Next.js App Router Metadata API

**Create `app/metadata.ts`** for shared metadata:

```typescript
import { Metadata } from 'next';

export const baseMetadata: Metadata = {
  metadataBase: new URL('https://waifugallery.com'), // Replace with your domain
  title: {
    default: 'Waifu Gallery - Anime Image Gallery & AI Search',
    template: '%s | Waifu Gallery'
  },
  description: 'Discover and collect beautiful anime-style images with AI-powered semantic search. Browse 30+ categories including waifu, neko, and more. Free anime image gallery.',
  keywords: [
    'anime images',
    'waifu gallery',
    'neko pictures',
    'anime art',
    'manga images',
    'kawaii pictures',
    'anime collection',
    'anime image search',
    'otaku gallery',
    'anime wallpapers'
  ],
  authors: [{ name: 'Waifu Gallery Team' }],
  creator: 'Waifu Gallery',
  publisher: 'Waifu Gallery',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://waifugallery.com',
    siteName: 'Waifu Gallery',
    title: 'Waifu Gallery - Anime Image Gallery & AI Search',
    description: 'Discover beautiful anime-style images with AI-powered search',
    images: [
      {
        url: '/og-image.png', // Create this 1200x630px image
        width: 1200,
        height: 630,
        alt: 'Waifu Gallery - Anime Image Collection',
      }
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Waifu Gallery - Anime Image Gallery',
    description: 'Discover beautiful anime-style images with AI-powered search',
    images: ['/twitter-image.png'], // Create this 1200x675px image
    creator: '@waifugallery', // Replace with your Twitter handle
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: [
      { url: '/favicon.ico' },
      { url: '/icon-16x16.png', sizes: '16x16', type: 'image/png' },
      { url: '/icon-32x32.png', sizes: '32x32', type: 'image/png' },
    ],
    apple: [
      { url: '/apple-touch-icon.png', sizes: '180x180', type: 'image/png' },
    ],
  },
  manifest: '/manifest.json',
};
```

### Update Each Page with Specific Metadata

**`app/page.tsx`** (Home):
```typescript
import { Metadata } from 'next';
import { baseMetadata } from './metadata';

export const metadata: Metadata = {
  ...baseMetadata,
  title: 'Waifu Gallery - Free Anime Image Gallery with AI Search',
  description: 'Browse thousands of anime-style images across 30+ categories. AI-powered semantic search, favorites collection, and mood-based filtering. Start exploring now!',
  openGraph: {
    ...baseMetadata.openGraph,
    title: 'Waifu Gallery - Free Anime Image Gallery',
    url: 'https://waifugallery.com',
  },
  alternates: {
    canonical: 'https://waifugallery.com',
  },
};
```

**`app/gallery/page.tsx`**:
```typescript
export const metadata: Metadata = {
  title: 'Gallery - Browse All Anime Images',
  description: 'Explore our complete anime image gallery with infinite scroll. Filter by 30+ categories including waifu, neko, hug, smile, and more.',
  openGraph: {
    title: 'Anime Image Gallery',
    url: 'https://waifugallery.com/gallery',
  },
  alternates: {
    canonical: 'https://waifugallery.com/gallery',
  },
};
```

**`app/search/page.tsx`**:
```typescript
export const metadata: Metadata = {
  title: 'AI-Powered Anime Image Search',
  description: 'Search for anime images using natural language. Try "cute happy catgirl" or "romantic couple". Our AI understands what you\'re looking for.',
  openGraph: {
    title: 'AI Anime Image Search',
    url: 'https://waifugallery.com/search',
  },
  alternates: {
    canonical: 'https://waifugallery.com/search',
  },
};
```

**`app/favorites/page.tsx`**:
```typescript
export const metadata: Metadata = {
  title: 'Your Favorite Anime Images',
  description: 'View and manage your saved anime images. Export your collection or import favorites from another device.',
  robots: {
    index: false, // Don't index personal collections
    follow: true,
  },
};
```

**`app/nsfw/page.tsx`**:
```typescript
export const metadata: Metadata = {
  title: 'NSFW Gallery (18+)',
  description: 'Adult anime content. Age verification required.',
  robots: {
    index: false, // Don't index NSFW content
    follow: false,
  },
};
```

---

## 2. Metadata Optimization

### Dynamic Category Pages

**Create `app/gallery/[category]/page.tsx`** for SEO-friendly category URLs:

```typescript
import { Metadata } from 'next';
import { CATEGORY_INFO, SFW_CATEGORIES } from '@/lib/constants';
import { notFound } from 'next/navigation';

type Props = {
  params: { category: string };
};

export async function generateStaticParams() {
  // Pre-render all category pages at build time
  return SFW_CATEGORIES.map((category) => ({
    category: category,
  }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const category = params.category;
  const categoryInfo = CATEGORY_INFO[category as keyof typeof CATEGORY_INFO];
  
  if (!categoryInfo) {
    return {};
  }

  const title = `${categoryInfo.name} Anime Images - ${categoryInfo.description}`;
  const description = `Browse ${categoryInfo.name.toLowerCase()} anime images. ${categoryInfo.description}. Discover similar content in our gallery.`;

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      url: `https://waifugallery.com/gallery/${category}`,
      images: [
        {
          url: `/og-${category}.png`, // You could generate these dynamically
          width: 1200,
          height: 630,
          alt: `${categoryInfo.name} anime images`,
        }
      ],
    },
    alternates: {
      canonical: `https://waifugallery.com/gallery/${category}`,
    },
    keywords: [
      `${categoryInfo.name} anime`,
      `${category} images`,
      'anime art',
      'manga pictures',
      ...categoryInfo.mood.map(mood => `${mood} anime`),
    ],
  };
}

export default function CategoryPage({ params }: Props) {
  const category = params.category;
  const categoryInfo = CATEGORY_INFO[category as keyof typeof CATEGORY_INFO];
  
  if (!categoryInfo) {
    notFound();
  }

  // Your existing gallery component
  return (
    <div>
      {/* Add H1 for SEO */}
      <h1 className="sr-only">{categoryInfo.name} Anime Images</h1>
      {/* Your gallery component */}
    </div>
  );
}
```

---

## 3. Structured Data (Schema.org)

### Add JSON-LD Structured Data

**Create `components/JsonLd.tsx`**:

```typescript
import Script from 'next/script';

export function WebsiteJsonLd() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: 'Waifu Gallery',
    description: 'Anime image gallery with AI-powered search',
    url: 'https://waifugallery.com',
    potentialAction: {
      '@type': 'SearchAction',
      target: {
        '@type': 'EntryPoint',
        urlTemplate: 'https://waifugallery.com/search?q={search_term_string}'
      },
      'query-input': 'required name=search_term_string'
    },
    audience: {
      '@type': 'Audience',
      audienceType: 'Anime and manga fans'
    }
  };

  return (
    <Script
      id="website-jsonld"
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
    />
  );
}

export function ImageGalleryJsonLd({ category }: { category: string }) {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ImageGallery',
    name: `${category} Anime Images`,
    description: `Collection of ${category} anime-style images`,
    url: `https://waifugallery.com/gallery/${category}`,
    image: `https://waifugallery.com/og-${category}.png`,
  };

  return (
    <Script
      id={`gallery-${category}-jsonld`}
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
    />
  );
}

export function OrganizationJsonLd() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Waifu Gallery',
    url: 'https://waifugallery.com',
    logo: 'https://waifugallery.com/logo.png',
    sameAs: [
      'https://twitter.com/waifugallery',
      'https://github.com/yourusername/waifu-gallery'
    ],
    contactPoint: {
      '@type': 'ContactPoint',
      contactType: 'Customer Service',
      email: 'support@waifugallery.com'
    }
  };

  return (
    <Script
      id="organization-jsonld"
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
    />
  );
}
```

**Add to `app/layout.tsx`**:
```typescript
import { WebsiteJsonLd, OrganizationJsonLd } from '@/components/JsonLd';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html>
      <head>
        <WebsiteJsonLd />
        <OrganizationJsonLd />
      </head>
      <body>{children}</body>
    </html>
  );
}
```

---

## 4. Image SEO

### Optimize Image Components

**Update `components/ImageCard.tsx`**:

```typescript
'use client';

import Image from 'next/image';
import { WaifuImage } from '@/types';

export function ImageCard({ image }: { image: WaifuImage }) {
  // Generate SEO-friendly alt text
  const altText = image.aiCaption 
    ? image.aiCaption 
    : `${image.category} anime image - ${image.aiTags?.join(', ') || 'cute anime art'}`;
  
  // Generate descriptive title
  const titleText = `${image.category} - ${image.aiMood || 'anime'} style`;

  return (
    <div className="relative group">
      <Image
        src={image.url}
        alt={altText}
        title={titleText}
        width={300}
        height={400}
        loading="lazy"
        quality={85}
        placeholder="blur"
        blurDataURL="data:image/svg+xml;base64,..." // Add blur placeholder
        className="rounded-lg"
        // Add descriptive filename in Next.js image optimization
        unoptimized={false}
      />
      
      {/* Add hidden text for screen readers and SEO */}
      <span className="sr-only">
        {altText}. Category: {image.category}. 
        {image.aiTags && ` Tags: ${image.aiTags.join(', ')}`}
      </span>
    </div>
  );
}
```

### Image Sitemap

**Create `app/sitemap-images.xml/route.ts`**:

```typescript
import { CATEGORY_INFO } from '@/lib/constants';

export async function GET() {
  const baseUrl = 'https://waifugallery.com';
  
  const imageUrls = Object.keys(CATEGORY_INFO).map(category => {
    return `
      <url>
        <loc>${baseUrl}/gallery/${category}</loc>
        <image:image>
          <image:loc>${baseUrl}/og-${category}.png</image:loc>
          <image:caption>${CATEGORY_INFO[category].description}</image:caption>
          <image:title>${CATEGORY_INFO[category].name} Anime Images</image:title>
        </image:image>
      </url>
    `;
  }).join('');

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
            xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
      ${imageUrls}
    </urlset>`;

  return new Response(xml, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600, must-revalidate',
    },
  });
}
```

---

## 5. Performance Optimization

### Core Web Vitals Improvements

**1. Image Optimization (LCP)**

```typescript
// In next.config.ts
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'i.waifu.pics',
        pathname: '/**',
      },
    ],
    formats: ['image/avif', 'image/webp'],
    deviceSizes: [640, 750, 828, 1080, 1200],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
  },
};
```

**2. Font Optimization (CLS)**

```typescript
// In app/layout.tsx
import { Inter } from 'next/font/google';

const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  preload: true,
  variable: '--font-inter',
});

export default function RootLayout({ children }) {
  return (
    <html className={inter.variable}>
      <body>{children}</body>
    </html>
  );
}
```

**3. Lazy Load Components (FID)**

```typescript
import dynamic from 'next/dynamic';

const ImageModal = dynamic(() => import('@/components/ImageModal'), {
  loading: () => <div>Loading...</div>,
  ssr: false,
});
```

---

## 6. Content Strategy

### Add SEO-Friendly Content Pages

**Create `app/about/page.tsx`** with rich content:

```typescript
export const metadata: Metadata = {
  title: 'About Waifu Gallery - Your Anime Image Hub',
  description: 'Learn about Waifu Gallery, the free anime image platform with AI-powered search. Discover how we help anime fans find and collect their favorite art.',
  alternates: {
    canonical: 'https://waifugallery.com/about',
  },
};

export default function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-6">About Waifu Gallery</h1>
      
      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">What is Waifu Gallery?</h2>
        <p className="text-lg leading-relaxed">
          Waifu Gallery is a free, community-driven anime image platform that helps 
          anime and manga fans discover, collect, and share beautiful anime-style artwork. 
          With AI-powered semantic search, you can find exactly what you're looking for 
          using natural language.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Features</h2>
        <ul className="space-y-3">
          <li>✨ <strong>AI-Powered Search:</strong> Find images using natural language queries</li>
          <li>🎨 <strong>30+ Categories:</strong> From waifus to nekos, hugs to smiles</li>
          <li>❤️ <strong>Favorites Collection:</strong> Save up to 500 images locally</li>
          <li>🌙 <strong>Dark Mode:</strong> Easy on the eyes for night browsing</li>
          <li>📱 <strong>PWA Support:</strong> Install as an app on any device</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Powered by waifu.pics API</h2>
        <p className="text-lg leading-relaxed">
          We use the excellent waifu.pics API to source all our images. This ensures 
          high-quality, curated anime content that's regularly updated.
        </p>
      </section>
    </div>
  );
}
```

### Blog for Long-tail Keywords (Optional)

**Create `app/blog/page.tsx`** and write articles like:
- "10 Best Anime Categories for Beginners"
- "How to Use AI Search for Anime Images"
- "Building Your Anime Image Collection: Tips & Tricks"

---

## 7. Social Media Integration

### Open Graph Images Generator

**Create `app/api/og/route.tsx`** (using @vercel/og):

```typescript
import { ImageResponse } from 'next/og';

export const runtime = 'edge';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get('category') || 'waifu';

  return new ImageResponse(
    (
      <div
        style={{
          display: 'flex',
          width: '100%',
          height: '100%',
          background: 'linear-gradient(135deg, #ec4899 0%, #8b5cf6 100%)',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div style={{ fontSize: 60, color: 'white' }}>
          🎨 {category} Gallery
        </div>
      </div>
    ),
    {
      width: 1200,
      height: 630,
    }
  );
}
```

---

## 8. Sitemap & Robots.txt

### Dynamic Sitemap

**Create `app/sitemap.ts`**:

```typescript
import { MetadataRoute } from 'next';
import { SFW_CATEGORIES } from '@/lib/constants';

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = 'https://waifugallery.com';
  
  // Static pages
  const staticPages = [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'daily' as const,
      priority: 1,
    },
    {
      url: `${baseUrl}/gallery`,
      lastModified: new Date(),
      changeFrequency: 'daily' as const,
      priority: 0.9,
    },
    {
      url: `${baseUrl}/search`,
      lastModified: new Date(),
      changeFrequency: 'weekly' as const,
      priority: 0.8,
    },
    {
      url: `${baseUrl}/about`,
      lastModified: new Date(),
      changeFrequency: 'monthly' as const,
      priority: 0.5,
    },
  ];

  // Category pages
  const categoryPages = SFW_CATEGORIES.map((category) => ({
    url: `${baseUrl}/gallery/${category}`,
    lastModified: new Date(),
    changeFrequency: 'daily' as const,
    priority: 0.7,
  }));

  return [...staticPages, ...categoryPages];
}
```

### Robots.txt

**Create `app/robots.ts`**:

```typescript
import { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  const baseUrl = 'https://waifugallery.com';

  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/favorites', '/nsfw'],
      },
      {
        userAgent: 'GPTBot',
        disallow: '/', // Block AI crawlers if desired
      },
    ],
    sitemap: `${baseUrl}/sitemap.xml`,
  };
}
```

---

## 9. Implementation Checklist

### Phase 1: Critical (Week 1)
- [ ] Add metadata to all pages
- [ ] Create dynamic category pages
- [ ] Add alt text to all images
- [ ] Implement sitemap.xml
- [ ] Create robots.txt
- [ ] Add canonical URLs
- [ ] Fix Core Web Vitals issues

### Phase 2: Enhanced (Week 2)
- [ ] Add JSON-LD structured data
- [ ] Create Open Graph images
- [ ] Optimize image loading
- [ ] Add breadcrumb navigation
- [ ] Create 404 page with helpful links
- [ ] Add internal linking structure

### Phase 3: Advanced (Week 3)
- [ ] Set up Google Search Console
- [ ] Submit sitemap to Google
- [ ] Create About page with rich content
- [ ] Add FAQ schema
- [ ] Implement image sitemap
- [ ] Create social sharing cards

### Phase 4: Analytics (Week 4)
- [ ] Install Google Analytics 4
- [ ] Set up conversion tracking
- [ ] Track popular searches
- [ ] Monitor Core Web Vitals
- [ ] A/B test titles/descriptions
- [ ] Create monthly SEO reports

---

## Quick Win Commands

```bash
# 1. Generate OG images (install sharp)
npm install sharp

# 2. Test metadata
npx @next/bundle-analyzer

# 3. Check performance
npm run build && npm run start
# Then use Lighthouse in Chrome DevTools

# 4. Validate structured data
# Visit: https://search.google.com/test/rich-results

# 5. Submit sitemap to Google
# Visit: https://search.google.com/search-console
```

---

## Expected Results

### Timeline
- **Week 1-2**: Google starts indexing
- **Month 1**: Appear for brand searches
- **Month 2-3**: Rank for long-tail keywords
- **Month 3-6**: Rank for competitive terms

### Target Keywords
- Primary: "anime image gallery", "waifu pics"
- Secondary: "neko images", "anime art search"
- Long-tail: "cute happy catgirl anime", "romantic anime couples"

### Success Metrics
- **50+ pages indexed** in first month
- **Core Web Vitals**: All green
- **Organic traffic**: 1000+ visitors/month by month 3
- **Average position**: Top 20 for target keywords

---

## Resources

- [Next.js SEO Documentation](https://nextjs.org/learn/seo/introduction-to-seo)
- [Google Search Central](https://developers.google.com/search)
- [Schema.org Markup](https://schema.org/)
- [Web.dev Performance](https://web.dev/measure/)

---

_Last Updated: February 2026_
