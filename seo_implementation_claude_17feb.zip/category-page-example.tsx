// app/gallery/[category]/page.tsx
// Example: Dynamic category page with full SEO implementation

import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { CATEGORY_INFO, SFW_CATEGORIES, type SfwCategory } from '@/lib/constants';
import { generateCategoryMetadata, SITE_URL } from '@/app/metadata.config';
import { ImageGalleryJsonLd, BreadcrumbJsonLd } from '@/components/seo/JsonLd';
import ImageGallery from '@/components/ImageGallery';

// ============================================
// TYPE DEFINITIONS
// ============================================
type Props = {
  params: { category: string };
  searchParams: { [key: string]: string | string[] | undefined };
};

// ============================================
// STATIC PARAMS GENERATION
// Pre-render all category pages at build time
// ============================================
export async function generateStaticParams() {
  return SFW_CATEGORIES.map((category) => ({
    category: category,
  }));
}

// ============================================
// DYNAMIC METADATA
// SEO metadata for each category
// ============================================
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const category = params.category as SfwCategory;
  const categoryInfo = CATEGORY_INFO[category];
  
  // Return 404 metadata if category doesn't exist
  if (!categoryInfo) {
    return {
      title: 'Category Not Found',
      robots: {
        index: false,
        follow: false,
      },
    };
  }

  // Generate rich metadata for the category
  return generateCategoryMetadata(
    categoryInfo.name,
    categoryInfo.description,
    categoryInfo.id,
    categoryInfo.mood
  );
}

// ============================================
// PAGE COMPONENT
// ============================================
export default function CategoryPage({ params }: Props) {
  const category = params.category as SfwCategory;
  const categoryInfo = CATEGORY_INFO[category];
  
  // Return 404 if category doesn't exist
  if (!categoryInfo) {
    notFound();
  }

  // Breadcrumb items for structured data
  const breadcrumbItems = [
    { name: 'Home', url: SITE_URL },
    { name: 'Gallery', url: `${SITE_URL}/gallery` },
    { name: categoryInfo.name, url: `${SITE_URL}/gallery/${category}` },
  ];

  return (
    <>
      {/* ============================================ */}
      {/* SEO: Structured Data */}
      {/* ============================================ */}
      <ImageGalleryJsonLd
        category={category}
        categoryName={categoryInfo.name}
        description={categoryInfo.description}
      />
      <BreadcrumbJsonLd items={breadcrumbItems} />

      {/* ============================================ */}
      {/* Main Content */}
      {/* ============================================ */}
      <div className="min-h-screen bg-white dark:bg-zinc-950">
        
        {/* SEO: Hidden H1 for screen readers and search engines */}
        <h1 className="sr-only">
          {categoryInfo.name} Anime Images - {categoryInfo.description}
        </h1>

        {/* Visible Header */}
        <header className="bg-gradient-to-r from-pink-500 to-purple-500 py-12 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-4 mb-4">
              <span className="text-6xl">{categoryInfo.icon}</span>
              <div>
                <h2 className="text-4xl font-bold text-white">
                  {categoryInfo.name}
                </h2>
                <p className="text-pink-100 mt-2">
                  {categoryInfo.description}
                </p>
              </div>
            </div>

            {/* Breadcrumb Navigation (Visible) */}
            <nav className="flex items-center gap-2 text-sm text-pink-100" aria-label="Breadcrumb">
              <a href="/" className="hover:text-white transition-colors">
                Home
              </a>
              <span>/</span>
              <a href="/gallery" className="hover:text-white transition-colors">
                Gallery
              </a>
              <span>/</span>
              <span className="text-white font-semibold">{categoryInfo.name}</span>
            </nav>

            {/* Category Metadata */}
            <div className="mt-6 flex flex-wrap gap-4">
              {/* Mood Tags */}
              {categoryInfo.mood.length > 0 && (
                <div className="flex items-center gap-2">
                  <span className="text-pink-100 text-sm">Moods:</span>
                  {categoryInfo.mood.map((mood) => (
                    <span
                      key={mood}
                      className="bg-white/20 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm"
                    >
                      {mood}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Gallery Component */}
        <main className="max-w-7xl mx-auto px-4 py-8">
          <ImageGallery 
            initialCategory={category}
            type="sfw"
          />
        </main>

        {/* SEO: Additional Content Section */}
        <section className="max-w-7xl mx-auto px-4 py-12 border-t border-zinc-200 dark:border-zinc-800">
          <h2 className="text-2xl font-bold mb-4">
            About {categoryInfo.name} Images
          </h2>
          <div className="prose dark:prose-invert max-w-none">
            <p className="text-lg text-zinc-600 dark:text-zinc-400 leading-relaxed">
              Explore our curated collection of {categoryInfo.name.toLowerCase()} anime images. 
              {categoryInfo.description}. Browse through hundreds of high-quality images, 
              save your favorites, and discover similar categories.
            </p>

            <h3 className="text-xl font-semibold mt-6 mb-3">
              Related Categories
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 not-prose">
              {SFW_CATEGORIES
                .filter(cat => {
                  const info = CATEGORY_INFO[cat];
                  return info.mood.some(mood => categoryInfo.mood.includes(mood)) && cat !== category;
                })
                .slice(0, 4)
                .map((relatedCat) => {
                  const info = CATEGORY_INFO[relatedCat];
                  return (
                    <a
                      key={relatedCat}
                      href={`/gallery/${relatedCat}`}
                      className="flex items-center gap-3 p-4 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:border-pink-500 dark:hover:border-pink-500 transition-colors"
                    >
                      <span className="text-3xl">{info.icon}</span>
                      <div>
                        <div className="font-semibold text-zinc-900 dark:text-white">
                          {info.name}
                        </div>
                        <div className="text-xs text-zinc-500">
                          {info.mood[0]}
                        </div>
                      </div>
                    </a>
                  );
                })}
            </div>

            <h3 className="text-xl font-semibold mt-6 mb-3">
              How to Use
            </h3>
            <ul className="space-y-2 text-zinc-600 dark:text-zinc-400">
              <li>🖱️ Click any image to view it in fullscreen</li>
              <li>❤️ Click the heart icon to save images to your favorites</li>
              <li>📥 Download images directly to your device</li>
              <li>🔄 Scroll down to load more images automatically</li>
              <li>🎨 Use filters to find specific moods or styles</li>
            </ul>
          </div>
        </section>

        {/* Call to Action */}
        <section className="bg-gradient-to-r from-pink-500 to-purple-500 py-12 px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-white mb-4">
              Can't find what you're looking for?
            </h2>
            <p className="text-pink-100 text-lg mb-6">
              Try our AI-powered semantic search to find exactly what you want using natural language.
            </p>
            <a
              href="/search"
              className="inline-block bg-white text-pink-600 font-semibold px-8 py-3 rounded-lg hover:bg-pink-50 transition-colors"
            >
              Try AI Search
            </a>
          </div>
        </section>
      </div>
    </>
  );
}

// ============================================
// REVALIDATION
// Rebuild this page every 24 hours
// ============================================
export const revalidate = 86400; // 24 hours in seconds

// ============================================
// NOTES FOR DEVELOPERS
// ============================================
/*
This category page includes:

1. ✅ Dynamic metadata generation
2. ✅ Structured data (JSON-LD)
3. ✅ Breadcrumb navigation
4. ✅ SEO-friendly URLs
5. ✅ Hidden H1 for accessibility
6. ✅ Rich content for search engines
7. ✅ Internal linking
8. ✅ Related categories
9. ✅ Clear call-to-action
10. ✅ Static generation at build time

Key SEO Features:
- Each category gets its own URL: /gallery/waifu, /gallery/neko, etc.
- Unique title and description for each category
- Structured data helps Google understand the content
- Breadcrumbs show site hierarchy
- Related categories create internal link structure
- Additional content provides context for search engines

Performance:
- Pages are pre-rendered at build time (ISR)
- Revalidate every 24 hours to keep content fresh
- Images lazy-loaded by ImageGallery component
- Optimized for Core Web Vitals

To customize:
1. Adjust the revalidation time (currently 24 hours)
2. Add more content to the "About" section
3. Customize related category logic
4. Add more internal links to other pages
5. Include user reviews or testimonials
*/
