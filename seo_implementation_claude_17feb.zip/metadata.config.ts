// app/metadata.config.ts
// Centralized SEO metadata configuration for Waifu Gallery

import { Metadata } from 'next';

// ============================================
// BASE URL - UPDATE THIS WITH YOUR DOMAIN
// ============================================
export const SITE_URL = 'https://waifugallery.com'; // TODO: Replace with your actual domain

// ============================================
// SITE INFORMATION
// ============================================
export const SITE_INFO = {
  name: 'Waifu Gallery',
  title: 'Waifu Gallery - Anime Image Gallery & AI Search',
  shortTitle: 'Waifu Gallery',
  description: 'Discover and collect beautiful anime-style images with AI-powered semantic search. Browse 30+ categories including waifu, neko, and more. Free anime image gallery.',
  tagline: 'Your Ultimate Anime Image Collection',
  twitter: '@waifugallery', // TODO: Add your Twitter handle
  email: 'support@waifugallery.com', // TODO: Add your email
  github: 'https://github.com/yourusername/waifu-gallery', // TODO: Add your GitHub
};

// ============================================
// KEYWORDS FOR SEO
// ============================================
export const SITE_KEYWORDS = [
  // Primary keywords
  'anime images',
  'waifu gallery',
  'anime art',
  'manga images',
  
  // Category keywords
  'neko pictures',
  'anime wallpapers',
  'kawaii pictures',
  'anime collection',
  
  // Feature keywords
  'anime image search',
  'AI anime search',
  'semantic anime search',
  
  // Audience keywords
  'otaku gallery',
  'anime fan',
  'manga lover',
  'weeb images',
];

// ============================================
// BASE METADATA (SHARED ACROSS ALL PAGES)
// ============================================
export const baseMetadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  
  title: {
    default: SITE_INFO.title,
    template: '%s | Waifu Gallery',
  },
  
  description: SITE_INFO.description,
  
  keywords: SITE_KEYWORDS,
  
  authors: [{ name: 'Waifu Gallery Team' }],
  creator: SITE_INFO.name,
  publisher: SITE_INFO.name,
  
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  
  // Open Graph (Facebook, LinkedIn, etc.)
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: SITE_URL,
    siteName: SITE_INFO.name,
    title: SITE_INFO.title,
    description: SITE_INFO.description,
    images: [
      {
        url: '/og-image.png', // TODO: Create this 1200x630px image
        width: 1200,
        height: 630,
        alt: 'Waifu Gallery - Anime Image Collection',
        type: 'image/png',
      }
    ],
  },
  
  // Twitter Card
  twitter: {
    card: 'summary_large_image',
    title: SITE_INFO.title,
    description: SITE_INFO.description,
    images: ['/twitter-image.png'], // TODO: Create this 1200x675px image
    creator: SITE_INFO.twitter,
    site: SITE_INFO.twitter,
  },
  
  // Search Engine Robots
  robots: {
    index: true,
    follow: true,
    nocache: false,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  
  // App Icons
  icons: {
    icon: [
      { url: '/favicon.ico', sizes: 'any' },
      { url: '/icon-16x16.png', sizes: '16x16', type: 'image/png' },
      { url: '/icon-32x32.png', sizes: '32x32', type: 'image/png' },
      { url: '/icon-192x192.png', sizes: '192x192', type: 'image/png' },
      { url: '/icon-512x512.png', sizes: '512x512', type: 'image/png' },
    ],
    apple: [
      { url: '/apple-touch-icon.png', sizes: '180x180', type: 'image/png' },
    ],
    other: [
      {
        rel: 'mask-icon',
        url: '/safari-pinned-tab.svg',
      },
    ],
  },
  
  // PWA Manifest
  manifest: '/manifest.json',
  
  // Application name for PWA
  applicationName: SITE_INFO.name,
  
  // Apple mobile web app
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: SITE_INFO.shortTitle,
  },
  
  // Verification (add when you have them)
  verification: {
    // google: 'your-google-verification-code', // TODO: Add after registering with Google Search Console
    // bing: 'your-bing-verification-code', // TODO: Add if using Bing Webmaster Tools
  },
  
  // Other metadata
  category: 'entertainment',
  classification: 'Anime & Manga Image Gallery',
};

// ============================================
// PAGE-SPECIFIC METADATA GENERATORS
// ============================================

export function generatePageMetadata({
  title,
  description,
  path = '',
  image,
  noIndex = false,
  keywords,
}: {
  title: string;
  description: string;
  path?: string;
  image?: string;
  noIndex?: boolean;
  keywords?: string[];
}): Metadata {
  const url = `${SITE_URL}${path}`;
  const ogImage = image || '/og-image.png';

  return {
    title,
    description,
    keywords: keywords || SITE_KEYWORDS,
    alternates: {
      canonical: url,
    },
    openGraph: {
      title,
      description,
      url,
      images: [
        {
          url: ogImage,
          width: 1200,
          height: 630,
          alt: title,
        }
      ],
    },
    twitter: {
      title,
      description,
      images: [ogImage],
    },
    robots: noIndex
      ? {
          index: false,
          follow: true,
        }
      : {
          index: true,
          follow: true,
        },
  };
}

// ============================================
// CATEGORY METADATA GENERATOR
// ============================================

export function generateCategoryMetadata(
  categoryName: string,
  categoryDescription: string,
  categorySlug: string,
  mood: string[]
): Metadata {
  const title = `${categoryName} Anime Images - ${categoryDescription}`;
  const description = `Browse ${categoryName.toLowerCase()} anime images. ${categoryDescription}. Discover similar content in our gallery.`;
  const keywords = [
    `${categoryName} anime`,
    `${categorySlug} images`,
    'anime art',
    'manga pictures',
    ...mood.map(m => `${m} anime`),
  ];

  return generatePageMetadata({
    title,
    description,
    path: `/gallery/${categorySlug}`,
    image: `/og-${categorySlug}.png`,
    keywords,
  });
}

// ============================================
// USAGE EXAMPLES IN YOUR PAGES
// ============================================

/*
// In app/page.tsx (Home)
import { generatePageMetadata } from './metadata.config';

export const metadata = generatePageMetadata({
  title: 'Waifu Gallery - Free Anime Image Gallery with AI Search',
  description: 'Browse thousands of anime-style images across 30+ categories. AI-powered semantic search, favorites collection, and mood-based filtering.',
  path: '/',
});

// In app/gallery/page.tsx
export const metadata = generatePageMetadata({
  title: 'Gallery - Browse All Anime Images',
  description: 'Explore our complete anime image gallery with infinite scroll. Filter by 30+ categories.',
  path: '/gallery',
});

// In app/favorites/page.tsx
export const metadata = generatePageMetadata({
  title: 'Your Favorite Anime Images',
  description: 'View and manage your saved anime images.',
  path: '/favorites',
  noIndex: true, // Don't index personal collections
});

// In app/gallery/[category]/page.tsx (Dynamic)
import { generateCategoryMetadata } from '@/app/metadata.config';
import { CATEGORY_INFO } from '@/lib/constants';

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const category = params.category;
  const info = CATEGORY_INFO[category];
  
  return generateCategoryMetadata(
    info.name,
    info.description,
    info.id,
    info.mood
  );
}
*/
