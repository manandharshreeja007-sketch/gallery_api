// components/seo/JsonLd.tsx
// Structured data components for SEO (Schema.org markup)

'use client';

import Script from 'next/script';
import { SITE_INFO, SITE_URL } from '@/app/metadata.config';

// ============================================
// WEBSITE SCHEMA
// For the homepage - enables site search in Google
// ============================================
export function WebsiteJsonLd() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: SITE_INFO.name,
    alternateName: SITE_INFO.shortTitle,
    description: SITE_INFO.description,
    url: SITE_URL,
    inLanguage: 'en-US',
    
    // Enable site search box in Google
    potentialAction: {
      '@type': 'SearchAction',
      target: {
        '@type': 'EntryPoint',
        urlTemplate: `${SITE_URL}/search?q={search_term_string}`
      },
      'query-input': 'required name=search_term_string'
    },
    
    audience: {
      '@type': 'Audience',
      audienceType: 'Anime and manga enthusiasts'
    }
  };

  return (
    <Script
      id="website-jsonld"
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      strategy="afterInteractive"
    />
  );
}

// ============================================
// ORGANIZATION SCHEMA
// Shows your brand info in search results
// ============================================
export function OrganizationJsonLd() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: SITE_INFO.name,
    url: SITE_URL,
    logo: {
      '@type': 'ImageObject',
      url: `${SITE_URL}/logo.png`,
      width: 512,
      height: 512
    },
    description: SITE_INFO.description,
    email: SITE_INFO.email,
    
    // Social media links
    sameAs: [
      SITE_INFO.twitter ? `https://twitter.com/${SITE_INFO.twitter.replace('@', '')}` : '',
      SITE_INFO.github || '',
    ].filter(Boolean),
    
    // Contact information
    contactPoint: {
      '@type': 'ContactPoint',
      contactType: 'Customer Service',
      email: SITE_INFO.email,
      availableLanguage: ['English']
    }
  };

  return (
    <Script
      id="organization-jsonld"
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      strategy="afterInteractive"
    />
  );
}

// ============================================
// WEB APPLICATION SCHEMA
// Describes your PWA capabilities
// ============================================
export function WebApplicationJsonLd() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebApplication',
    name: SITE_INFO.name,
    description: SITE_INFO.description,
    url: SITE_URL,
    applicationCategory: 'EntertainmentApplication',
    browserRequirements: 'Requires JavaScript. Requires HTML5.',
    operatingSystem: 'Any',
    offers: {
      '@type': 'Offer',
      price: '0',
      priceCurrency: 'USD'
    },
    featureList: [
      'AI-powered semantic search',
      'Infinite scroll gallery',
      'Favorites collection',
      'Dark mode support',
      'Progressive Web App',
      '30+ anime categories'
    ]
  };

  return (
    <Script
      id="webapp-jsonld"
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      strategy="afterInteractive"
    />
  );
}

// ============================================
// IMAGE GALLERY SCHEMA
// For category pages - helps Google understand image collections
// ============================================
export function ImageGalleryJsonLd({ 
  category, 
  categoryName, 
  description 
}: { 
  category: string; 
  categoryName: string;
  description: string;
}) {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ImageGallery',
    name: `${categoryName} Anime Images`,
    description: description,
    url: `${SITE_URL}/gallery/${category}`,
    image: `${SITE_URL}/og-${category}.png`,
    datePublished: new Date().toISOString(),
    inLanguage: 'en-US',
    about: {
      '@type': 'Thing',
      name: categoryName,
      description: description
    }
  };

  return (
    <Script
      id={`gallery-${category}-jsonld`}
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      strategy="afterInteractive"
    />
  );
}

// ============================================
// BREADCRUMB SCHEMA
// Shows navigation path in search results
// ============================================
export function BreadcrumbJsonLd({ 
  items 
}: { 
  items: Array<{ name: string; url: string }> 
}) {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: item.url
    }))
  };

  return (
    <Script
      id="breadcrumb-jsonld"
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      strategy="afterInteractive"
    />
  );
}

// ============================================
// FAQ SCHEMA
// For FAQ/About pages - shows in rich snippets
// ============================================
export function FAQJsonLd({ 
  faqs 
}: { 
  faqs: Array<{ question: string; answer: string }> 
}) {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map(faq => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer
      }
    }))
  };

  return (
    <Script
      id="faq-jsonld"
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      strategy="afterInteractive"
    />
  );
}

// ============================================
// IMAGE OBJECT SCHEMA
// For individual images - helps with Google Images
// ============================================
export function ImageObjectJsonLd({
  url,
  caption,
  category,
  width = 800,
  height = 1200,
}: {
  url: string;
  caption: string;
  category: string;
  width?: number;
  height?: number;
}) {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ImageObject',
    contentUrl: url,
    description: caption,
    name: caption,
    encodingFormat: 'image/jpeg',
    width: width,
    height: height,
    about: {
      '@type': 'Thing',
      name: category,
      description: `${category} anime image`
    },
    license: 'https://creativecommons.org/licenses/by-nc/4.0/', // Adjust based on your license
    creditText: 'Powered by waifu.pics API',
    creator: {
      '@type': 'Organization',
      name: 'waifu.pics'
    }
  };

  return (
    <Script
      id={`image-${url.split('/').pop()}-jsonld`}
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      strategy="lazyOnload"
    />
  );
}

// ============================================
// COLLECTION PAGE SCHEMA
// For the main gallery listing
// ============================================
export function CollectionPageJsonLd() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'CollectionPage',
    name: 'Anime Image Gallery',
    description: 'Browse our complete collection of anime-style images across multiple categories',
    url: `${SITE_URL}/gallery`,
    isPartOf: {
      '@type': 'WebSite',
      url: SITE_URL,
      name: SITE_INFO.name
    },
    about: {
      '@type': 'Thing',
      name: 'Anime Art Collection',
      description: 'Curated collection of anime and manga style artwork'
    }
  };

  return (
    <Script
      id="collection-jsonld"
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      strategy="afterInteractive"
    />
  );
}

// ============================================
// USAGE EXAMPLES
// ============================================

/*
// In app/layout.tsx (Root Layout)
import { WebsiteJsonLd, OrganizationJsonLd, WebApplicationJsonLd } from '@/components/seo/JsonLd';

export default function RootLayout({ children }) {
  return (
    <html>
      <head>
        <WebsiteJsonLd />
        <OrganizationJsonLd />
        <WebApplicationJsonLd />
      </head>
      <body>{children}</body>
    </html>
  );
}

// In app/gallery/page.tsx
import { CollectionPageJsonLd } from '@/components/seo/JsonLd';

export default function GalleryPage() {
  return (
    <>
      <CollectionPageJsonLd />
      <div>Your gallery content...</div>
    </>
  );
}

// In app/gallery/[category]/page.tsx
import { ImageGalleryJsonLd, BreadcrumbJsonLd } from '@/components/seo/JsonLd';

export default function CategoryPage({ params }) {
  const categoryInfo = CATEGORY_INFO[params.category];
  
  return (
    <>
      <ImageGalleryJsonLd
        category={params.category}
        categoryName={categoryInfo.name}
        description={categoryInfo.description}
      />
      <BreadcrumbJsonLd
        items={[
          { name: 'Home', url: SITE_URL },
          { name: 'Gallery', url: `${SITE_URL}/gallery` },
          { name: categoryInfo.name, url: `${SITE_URL}/gallery/${params.category}` }
        ]}
      />
      <div>Your category content...</div>
    </>
  );
}

// In app/about/page.tsx
import { FAQJsonLd } from '@/components/seo/JsonLd';

export default function AboutPage() {
  const faqs = [
    {
      question: 'What is Waifu Gallery?',
      answer: 'Waifu Gallery is a free anime image platform with AI-powered search.'
    },
    // Add more FAQs...
  ];

  return (
    <>
      <FAQJsonLd faqs={faqs} />
      <div>Your about content...</div>
    </>
  );
}
*/
