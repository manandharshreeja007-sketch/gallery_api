// app/sitemap.ts
// Dynamic sitemap generation for search engines

import { MetadataRoute } from 'next';
import { SFW_CATEGORIES } from '@/lib/constants';

const SITE_URL = 'https://waifugallery.com'; // TODO: Update with your domain

export default function sitemap(): MetadataRoute.Sitemap {
  const currentDate = new Date();
  
  // ============================================
  // STATIC PAGES
  // ============================================
  const staticPages: MetadataRoute.Sitemap = [
    {
      url: SITE_URL,
      lastModified: currentDate,
      changeFrequency: 'daily',
      priority: 1.0, // Highest priority for homepage
    },
    {
      url: `${SITE_URL}/gallery`,
      lastModified: currentDate,
      changeFrequency: 'daily',
      priority: 0.9, // High priority for main gallery
    },
    {
      url: `${SITE_URL}/search`,
      lastModified: currentDate,
      changeFrequency: 'weekly',
      priority: 0.8, // Important feature page
    },
    {
      url: `${SITE_URL}/about`,
      lastModified: currentDate,
      changeFrequency: 'monthly',
      priority: 0.5, // Lower priority for about page
    },
    {
      url: `${SITE_URL}/contact`,
      lastModified: currentDate,
      changeFrequency: 'monthly',
      priority: 0.5,
    },
    {
      url: `${SITE_URL}/privacy`,
      lastModified: currentDate,
      changeFrequency: 'yearly',
      priority: 0.3,
    },
    {
      url: `${SITE_URL}/terms`,
      lastModified: currentDate,
      changeFrequency: 'yearly',
      priority: 0.3,
    },
  ];

  // ============================================
  // CATEGORY PAGES (Dynamic)
  // ============================================
  const categoryPages: MetadataRoute.Sitemap = SFW_CATEGORIES.map((category) => ({
    url: `${SITE_URL}/gallery/${category}`,
    lastModified: currentDate,
    changeFrequency: 'daily' as const,
    priority: 0.7, // Medium-high priority for category pages
  }));

  // ============================================
  // COMBINE ALL PAGES
  // ============================================
  return [...staticPages, ...categoryPages];
}

// ============================================
// SITEMAP INDEX (Optional - for large sites)
// ============================================
// If you have 1000+ URLs, create multiple sitemaps

/*
// Create app/sitemap-index.xml/route.ts
export async function GET() {
  const sitemaps = `<?xml version="1.0" encoding="UTF-8"?>
    <sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
      <sitemap>
        <loc>${SITE_URL}/sitemap-pages.xml</loc>
        <lastmod>${new Date().toISOString()}</lastmod>
      </sitemap>
      <sitemap>
        <loc>${SITE_URL}/sitemap-categories.xml</loc>
        <lastmod>${new Date().toISOString()}</lastmod>
      </sitemap>
      <sitemap>
        <loc>${SITE_URL}/sitemap-images.xml</loc>
        <lastmod>${new Date().toISOString()}</lastmod>
      </sitemap>
    </sitemapindex>`;

  return new Response(sitemaps, {
    headers: {
      'Content-Type': 'application/xml',
    },
  });
}
*/
